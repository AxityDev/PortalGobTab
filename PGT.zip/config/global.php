<?php
define("CONTROLADOR_DEFECTO", "usuario");
define("ACCION_DEFECTO", "index");
?>
