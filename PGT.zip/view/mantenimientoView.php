<div class="container">
	<h1 style="text-align: center;">Plataforma en mantenimiento</h1>
	<h3 style="text-align: center;">Actualizando datos de planta</h3>
</div>